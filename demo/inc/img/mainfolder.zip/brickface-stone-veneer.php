<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<?php $currentpage = "brickface"; ?>
<html>
<head>
	<title>George J. Grove &amp; Son - Replacement Windows, Doors, Siding, Roofing, and More</title>
	<link rel="stylesheet" href="inc/grovestyle.css" type="text/css">
</head>

<body>
<div align="center">
	<div id="shell">
		<?php  include("inc/header.php"); ?>	
		<div id="content">
			<?php include("inc/leftmenu.php"); ?>			
			<div id="content-right">
				<div style="width:100%;height:17px;float:left;overflow:hidden;"></div>
				<?php 
				$val0 = $_GET['style'];
				$val = $_GET['color'];
				$val2 = $_GET['joint'];
				$val3 = $_GET['accents'];
				include("inc/brickfaceheader.php");
				if ($val0 == "") {
					include("inc/brickfacestyle.php");
				} elseif ($val == "") {
					if ($val0 == "standard" || $val0 == "handcrafted" )
						include("inc/brickfacecolor.php");
					else 
						include("inc/brickfacestonecolor.php");
				} elseif ($val2 == "") {
					include("inc/brickfacestonejoint.php");
				} elseif ($val3 == "") {
					include("inc/brickfacestoneaccents.php");
				} else {					
					include("inc/buy.php");
				}
				?>
				<p style="padding-bottom:20px;">&nbsp;</p>
				<?php include("inc/testimonials.php"); ?>	
			</div>
		</div>
		<?php include("inc/footer.php"); ?>	
	</div>
</div>

</body>
</html>