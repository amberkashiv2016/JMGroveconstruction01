<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<?php $currentpage = "home"; ?>
<html>
<head>
	<title>George J. Grove &amp; Son - Replacement Windows, Doors, Siding, Roofing, and More</title>
	<link rel="stylesheet" href="inc/grovestyle.css" type="text/css">
</head>

<body>
<div align="center">
	<div id="shell">
		<div id="header">
			<div id="header-top"></div>
			<div id="header-mid">
				<div style="float:left;width:65%">
					<p style="padding: 20px 0px 0px 12px;"><a href="index.html"><img src="img/george-j-grove-replacement-windows.jpg" border="0" alt="George J. Grove Replacement Windows"></a></p>
				</div>
				<div style="float:left;width:35%;height:124px;background: url(img/header-vdiv.jpg) no-repeat;">
					<p style="padding: 12px 0px 0px 22px;">Call Us Toll-Free</p>
					<p style="padding: 0px 0px 0px 22px;"><strong>1-800-393-0859</strong></p>
					<p style="padding: 0px 0px 0px 22px;font-size:.8em;">1219 Manheim Pike, Lancaster, PA 17601</p>
					<p style="padding: 0px 0px 0px 22px;font-size:.8em;"><a href="mailto:info@georgejgrove.com" style="text-decoration:none;">info@georgejgrove.com</a></p>
				</div>	
			</div>
			<div id="header-bottom"></div>
		</div>
		<div id="splash" style="height:150px;">
			<div id="splash-left" style="height:144px;">
				<div style="float:left;background: url(img/splash-left-top.jpg) no-repeat;height:10px;width:100%;overflow:hidden;"></div>
				<div align="left" style="float:left;width:100%;height:124px;overflow:hidden;">
					<p align="left" style="padding: 5px 0 0 15px;"><img src="img/home-building-trust.gif" alt="Building Trust Since 1963"></p>
					<ul>
						<li>Service &amp; Quality Guaranteed</li>
						<li>Energy Star Approved Products</li>
						<li>Customer Satisfaction is Our Top Priority</li>
					</ul>
				</div>
				<div style="float:left;background: url(img/splash-left-bottom.jpg);height:10px;width:100%;overflow:hidden;"></div>
			</div>
			<div id="splash-right" style="height:144px;">
				<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,29,0" width="610" height="144">
					<param name="movie" value="pub/home.swf">
					<param name="quality" value="high">
					<embed src="pub/home.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="610" height="144"></embed>
				</object>
			</div>
			<div id="splash-footer"></div>
		</div>
		<div id="content">
			<?php include("inc/leftmenu.php"); ?>				
			<div id="content-right" style="background: url(img/home-downspout.jpg) no-repeat; background-position: top right;">
				<div style="width:100%;height:22px;float:left;overflow:hidden;"></div>
				<div style="width:100%;float:left;height:230px;overflow:hidden;">
					<div style="width:20%;float:left;text-align:right;"><img src="img/home-door-window-customize.jpg" border="0" style="padding-bottom:2px;padding-left:15px;"></div>
					<div style="width:80%;float:left;overflow:hidden;">
						<h4 style="padding: 12px 20px 0px 60px;font-size:1.1em;">
							Design Your Own Custom Project
						</h4>
						<p style="padding: 0px 20px 5px 60px;font-size:.8em;">
							<a href="#" style="color:#c72121;text-decoration:none;">Click here to pick the options that are right for you<img src="img/arrow-red.jpg" border="0" style="margin-left:8px;"></a>
						</p>
						<p style="padding: 0px 55px 10px 60px;font-size:.8em;">
							George J. Grove &amp; Son is dedicated to supplying our customers with the <strong>highest quality products and service</strong> available. Start designing your dream home today and experience luxury as unique as your home.
							<br><br><strong>George J. Grove &amp; Son &mdash; The home of quality for over 50 years</strong>.
						</p>
						<p style="padding: 8px 20px 5px 20px;" align="center">
							<a href="#"><img src="img/button-start-customizing-now.jpg" border="0"></a>
						</p>
					</div>
				</div>
				<div style="width:100%;float:left;background: url(img/background-savings.jpg) repeat-x;margin-top:40px;overflow:hidden;height:147px;">
					<div style="width:305px;float:left;height:147px;background: url(img/home-savings.jpg) no-repeat;background-position: 11px 0px;overflow:hidden;">
						<h2 align="left" style="padding: 0px 0px 0px 74px;font-weight:800;font-size:1.2em;color:#009900">Save 35% on Energy Bills!</h2>
						<p align="right" style="padding: 6px 3px 18px 0px;">
							<!---Save on your bills and increase the value of your home!<br>--->
							<a href="#"><img src="img/button-savings.gif" border="0"></a>
						</p>
						<p align="left" style="padding: 3px 15px 18px 90px;font-size:.8em;color:#026000">
							We are a <strong style="color:#026000">green company</strong> and sell <strong style="color:#026000">green products</strong>.
						</p>
					</div>
					<div style="width:18px;float:left;height:147px;background: url(img/home-testimonials-vdiv.jpg) no-repeat;background-position: top right;overflow:hidden;">
						
					</div>
					<div style="width:310px;float:left;height:147px;background: url(img/home-testimonials.jpg) repeat-x;overflow:hidden;">
						<strong style="padding-left:15px;color:#c72121;font-size:1.1em;">Customer Testimonials</strong>
						<p style="padding:0px 15px 5px 12px; font-size:.8em;">
							"I'm so happy with the windows my wife and I had installed in our home. Not only does our house 
							look much better, our energy bill is 40% less and the value of our home has increased as well!" 
							<em>Tyler C., New Brunswick, NJ</em>
						</p>
					</div>
					<div style="width:79px;float:left;height:147px;background: url(img/home-testimonials.jpg) repeat-x;overflow:hidden;">
						<p align="right" style="padding: 15px 30px 15px 0;"><img src="img/home-bbb.jpg" alt="Better Business Bureu"></p>
					</div>
				</div>
			</div>
		</div>
		<div id="footer">
			<div id="footer-top">
				<div style="float:left;padding: 15px 18px 0px 18px;font-size:.8em;"><a href="#" style="text-decoration:none;">About Us</a></div>
				<div style="float:left;"><img src="img/footer-vdiv.jpg"></div>
				<div style="float:left;padding: 15px 18px 0px 18px;font-size:.8em;"><a href="#" style="text-decoration:none;">Contact Us</a></div>
				<div style="float:left;"><img src="img/footer-vdiv.jpg"></div>
				<div style="float:left;padding: 15px 18px 0px 18px;font-size:.8em;"><a href="#" style="text-decoration:none;">Employment</a></div>
				<div style="float:left;"><img src="img/footer-vdiv.jpg"></div>
				<div style="float:left;padding: 15px 18px 0px 18px;font-size:.8em;"><a href="#" style="text-decoration:none;">Financing</a></div>
				<div style="float:right;padding: 15px 18px 0px 18px;font-size:.8em;color:#777;">Copyright George J. Grove &amp; Son, Inc. All Rights Reserved.</div>
			</div>
			<div id="footer-bottom"></div>
		</div>
	</div>
</div>

</body>
</html>