<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<?php $currentpage = "windows"; ?>
<html>
<head>
	<title>George J. Grove &amp; Son - Replacement Windows, Doors, Siding, Roofing, and More</title>
	<link rel="stylesheet" href="inc/grovestyle.css" type="text/css">
</head>

<body>
<div align="center">
	<div id="shell">
		<?php  include("inc/header.php"); ?>	
		<div id="content">
			<?php include("inc/leftmenu.php"); ?>			
			<div id="content-right">
				<div style="width:100%;height:17px;float:left;overflow:hidden;"></div>
				<?php 
				$val0 = $_GET['type'];
				$val = $_GET['style'];
				$val2 = $_GET['color'];
				$val3 = $_GET['glass'];
				include("inc/windowheader.php");
				if ($val0 == "") {
					include("inc/windowtype.php");
				} elseif ($val == "") {
					include("inc/windowstyle.php");
				} elseif ($val2 == "") {
					include("inc/windowcolor.php");
				} elseif ($val3 == "") {
					include("inc/windowglass.php");
				} else {
					include("inc/buy.php");
				}
				?>
				<p style="padding-bottom:20px;">&nbsp;</p>
				<?php include("inc/testimonials.php"); ?>	
			</div>
		</div>
		<?php include("inc/footer.php"); ?>	
	</div>
</div>

</body>
</html>